BOPNN_LDA <- function(data_df, nn = 3, ndim = NULL, dim_prop1 = .5, ndim_samp = NULL, dim_prop0 = min(.75, 5/sqrt(ncol(data_df))), n_prop = 0.63, nbag = 100, coarseness = 6, vimp = FALSE, eps0 = NULL, eps1 = NULL, cores = 1, OOB = FALSE, case_weights = "stratified", plotMat = FALSE, LDA = TRUE){
  if(!('y'%in%names(data_df))) stop('data_df must contain a response named "y"')
  n <- nrow(data_df)
  
  nnp <- nn
  
  x0 <- data_df[,names(data_df)!='y']
  y0 <- data_df$y
  
  if(is.null(ndim_samp)) ndim_samp <- max(2, floor(ncol(x0)*dim_prop0))
  if(is.null(ndim)) ndim <- max(2, floor(ndim_samp*dim_prop1))
  n_samp <- floor(n*n_prop)
  
  if(is.null(eps0)) eps0 <- sqrt(ndim_samp)/2
  if(is.null(eps1)) eps1 <- sqrt(ndim)/2 - 1
  
  convert <- which(unlist(lapply(x0, function(l){
    if(is.factor(l)) TRUE
    else if(typeof(l)=='integer' & length(unique(l)) <= coarseness) TRUE
    else FALSE
  })))
  
  scaled <- one_hot_scale(x0, convert)
  
  X <- scaled[[1]]
  idxs <- scaled[[2]]
  scales <- scaled[[3]]
  
  d <- ncol(x0)
  
  ylevs <- levels(as.factor(y0))
  
  y <- as.numeric(as.factor(y0))
  
  mypi <- table(y)*n_prop
  
  Y <- sapply(1:max(y), function(k) y==k)*1
  
  if(cores > 1){
    cluster <- makeCluster(cores)
    clusterExport(cluster, c(ls(), 'nn2'), envir = environment())
    
    mods <- parLapply(cl = cluster, 1:nbag,
                      function(x){
                        if(is.null(case_weights)) smp <- sample(1:n, n_samp)
                        else if(case_weights=="stratified") smp <- unlist(lapply(1:max(y), function(k) sample(which(y==k), ceiling(mypi[k]))))
                        else smp <- sample(1:n, n_samp, prob = case_weights, replace = TRUE)
                        dsmp <- sample(1:d, ndim_samp)
                        duse <- which(idxs%in%dsmp)
                        
                        if(LDA){
                          mu <- t(sapply(1:max(y), function(k) colMeans(X[smp[y[smp]==k],duse])))
                          M <- X[smp,duse] - mu[y[smp],]
                          dr <- Re(eigen(solve(t(M)%*%M + diag(length(duse))*1e-10)%*%cov(X[smp,duse]))$vectors[,1:ndim])
                        }
                        else{
                          dr <- eigs_sym(cov(X[smp,duse]), ndim)$vectors
                        }
                        
                        
                        if(OOB){
                          nns <- nn2(X[smp,duse]%*%dr, query = X[-smp,duse]%*%dr, k = nn, eps = eps1)$nn.idx
                          pr_oob <- Y*0
                          for(nnn in 1:nn) pr_oob[-smp,] <- pr_oob[-smp,] + Y[smp[nns[,nnn]],]/nn
                          return(list(dr = dr, duse = duse, ixs = smp, pr_oob = pr_oob, oob = t(apply(pr_oob, 1, function(z) z==max(z)))))
                        }
                        else return(list(dr = dr, duse = duse, ixs = smp))
                      })
    stopCluster(cluster)
    
  }
  else{
    mods <- lapply(1:nbag,
                   function(x){
                     if(is.null(case_weights)) smp <- sample(1:n, n_samp)
                     else if(case_weights=="stratified") smp <- unlist(lapply(1:max(y), function(k) sample(which(y==k), ceiling(mypi[k]))))
                     else smp <- sample(1:n, n_samp, prob = case_weights, replace = TRUE)
                     dsmp <- sample(1:d, ndim_samp)
                     duse <- which(idxs%in%dsmp)
                     
                     if(LDA){
                       mu <- t(sapply(1:max(y), function(k) colMeans(X[smp[y[smp]==k],duse])))
                       M <- X[smp,duse] - mu[y[smp],]
                       dr <- Re(eigen(solve(t(M)%*%M + diag(length(duse))*1e-10)%*%cov(X[smp,duse]))$vectors[,1:ndim])
                     }
                     else{
                       dr <- eigs_sym(cov(X[smp,duse]), ndim)$vectors
                     }
                     
                     if(OOB){
                       nns <- nn2(X[smp,duse]%*%dr, query = X[-smp,duse]%*%dr, k = nn, eps = eps1)$nn.idx
                       pr_oob <- Y*0
                       for(nnn in 1:nn) pr_oob[-smp,] <- pr_oob[-smp,] + Y[smp[nns[,nnn]],]/nn
                       return(list(dr = dr, duse = duse, ixs = smp, pr_oob = pr_oob, oob = t(apply(pr_oob, 1, function(z) z==max(z)))))
                     }
                     else return(list(dr = dr, duse = duse, ixs = smp))
                   })
  }
  if(vimp){
    vvals <- numeric(d)
    for(b in 1:nbag){
      Vb <- mods[[b]]$dr*matrix(sqrt(mods[[b]]$evals), nrow(mods[[b]]$dr), ncol(mods[[b]]$dr), byrow = TRUE)
      Delta <- rowSums(Vb^2)
      for(dd in 1:d){
        idi <- which(idxs[mods[[b]]$duse]==dd)
        if(length(idi) > 0) vvals[dd] <- vvals[dd] + mean(Delta[idi])
      }
    }
  }
  else vvals <- numeric(d)
  if(plotMat){
    X0 <- X*0
    for(b in 1:nbag) X0 <- X0 + X[,mods[[b]]$duse]%*%mods[[b]]$dr%*%t(mods[[b]]$dr)%*%t(sapply(mods[[b]]$duse, function(dd) (1:ncol(X))==dd))
    dr_all <- eigen(cov(X0))$vectors
  }
  else dr_all <- NULL
  if(OOB){
    Cl <- Y*0
    P <- Cl
    for(b in 1:nbag){
      Cl <- Cl + mods[[b]]$oob/nbag
      P <- P + mods[[b]]$pr_oob/nbag
    } 
    return(structure(list(mods = mods, probs_oob = P/rowSums(P), predicted.oob = ylevs[apply(Cl, 1, which.max)], oob.uncertainty = -apply(Cl/rowSums(Cl), 1, function(p) sum(p*log(p+1e-100))), ooberr = mean(apply(Cl, 1, which.max)!=y), nn = nn, convert = convert, idxs = idxs, X = X, x0 = x0, ylevs = ylevs, y = y, scales = scales, vimp = vvals/nbag, dr_all = dr_all, eps = eps1), class = 'BOPNN'))
  }
  else return(structure(list(mods = mods, nn = nn, convert = convert, idxs = idxs, X = X, x0 = x0, ylevs = ylevs, y = y, scales = scales, vimp = vvals/nbag, dr_all = dr_all, eps = eps1), class = 'BOPNN'))
}



BOPNN_tune_parallel_LDA <- function(data_df, ranges = list(), beta_params = list(), nsamp = 30, eps0 = NULL, eps1 = NULL, cores = 1, case_weights = "stratified", coarseness = 6, LDA = TRUE){
  if(is.null(ranges$nn)) ranges$nn <- c(1, 5)
  if(is.null(ranges$dim_prop0)) ranges$dim_prop0 <- ncol(data_df)^(-.5)*c(1, min(10, ncol(data_df)^.5))
  if(is.null(ranges$dim_prop1)) ranges$dim_prop1 <- c(1/2, .9)
  if(is.null(ranges$n_prop)) ranges$n_prop <- c(.63, .63)
  
  if(is.null(beta_params$nn)) beta_params$nn <- c(1, 1)
  if(is.null(beta_params$dim_prop0)) beta_params$dim_prop0 <- c(1, 1)
  if(is.null(beta_params$dim_prop1)) beta_params$dim_prop1 <- c(1, 1)
  if(is.null(beta_params$n_prop)) beta_params$n_prop <- c(1, 1)
  
  cluster <- makeCluster(cores)
  clusterExport(cluster, c(ls(), 'nn2', 'BOPNN_LDA', 'one_hot_scale', 'eigs_sym', 'lda'), envir = environment())
  
  mods <- parLapply(cl = cluster, 1:nsamp,
                    function(x){
                      nn <- round(rbeta(1, beta_params$nn[1], beta_params$nn[2])*(ranges$nn[2]-ranges$nn[1])+ranges$nn[1])
                      dim_prop0 <- rbeta(1, beta_params$dim_prop0[1], beta_params$dim_prop0[2])*(ranges$dim_prop0[2]-ranges$dim_prop0[1])+ranges$dim_prop0[1]
                      dim_prop1 <- rbeta(1, beta_params$dim_prop1[1], beta_params$dim_prop1[2])*(ranges$dim_prop1[2]-ranges$dim_prop1[1])+ranges$dim_prop1[1]
                      n_prop <- rbeta(1, beta_params$n_prop[1], beta_params$n_prop[2])*(ranges$n_prop[2]-ranges$n_prop[1])+ranges$n_prop[1]
                      mod <- try(BOPNN_LDA(data_df, nn = nn, dim_prop1 = dim_prop1, dim_prop0 = dim_prop0, n_prop = n_prop, eps0 = eps0, eps1 = eps1, OOB = TRUE, cores = 1, case_weights = case_weights, coarseness = coarseness, LDA = LDA))
                      if(inherits(mod, 'try-error')) return(list(ooberr = 1))
                      else return(mod)
                    })
  stopCluster(cluster)
  prfs <- unlist(lapply(mods, function(l) l$ooberr))
  mods[[which.min(prfs)]]
}


BOPNN0_tune_parallel <- function(data_df, ranges = list(), beta_params = list(), nsamp = 30, eps0 = NULL, eps1 = NULL, cores = 1, case_weights = "stratified", coarseness = 6){
  if(is.null(ranges$nn)) ranges$nn <- c(1, 5)
  if(is.null(ranges$dim_prop0)) ranges$dim_prop0 <- ncol(data_df)^(-.5)*c(1, min(10, ncol(data_df)^.5))
  if(is.null(ranges$dim_prop1)) ranges$dim_prop1 <- c(1/2, .9)
  if(is.null(ranges$n_prop)) ranges$n_prop <- c(.63, .63)
  
  if(is.null(beta_params$nn)) beta_params$nn <- c(1, 1)
  if(is.null(beta_params$dim_prop0)) beta_params$dim_prop0 <- c(1, 1)
  if(is.null(beta_params$dim_prop1)) beta_params$dim_prop1 <- c(1, 1)
  if(is.null(beta_params$n_prop)) beta_params$n_prop <- c(1, 1)
  
  cluster <- makeCluster(cores)
  clusterExport(cluster, c(ls(), 'nn2', 'BOPNN0', 'one_hot_scale'), envir = environment())
  
  mods <- parLapply(cl = cluster, 1:nsamp,
                    function(x){
                      nn <- round(rbeta(1, beta_params$nn[1], beta_params$nn[2])*(ranges$nn[2]-ranges$nn[1])+ranges$nn[1])
                      dim_prop0 <- rbeta(1, beta_params$dim_prop0[1], beta_params$dim_prop0[2])*(ranges$dim_prop0[2]-ranges$dim_prop0[1])+ranges$dim_prop0[1]
                      dim_prop1 <- rbeta(1, beta_params$dim_prop1[1], beta_params$dim_prop1[2])*(ranges$dim_prop1[2]-ranges$dim_prop1[1])+ranges$dim_prop1[1]
                      n_prop <- rbeta(1, beta_params$n_prop[1], beta_params$n_prop[2])*(ranges$n_prop[2]-ranges$n_prop[1])+ranges$n_prop[1]
                      mod <- try(BOPNN0(data_df, nn = nn, dim_prop1 = dim_prop1, dim_prop0 = dim_prop0, n_prop = n_prop, eps0 = eps0, eps1 = eps1, OOB = TRUE, cores = 1, case_weights = case_weights, coarseness = coarseness))
                      if(inherits(mod, 'try-error')) return(list(ooberr = 1))
                      else return(mod)
                    })
  stopCluster(cluster)
  prfs <- unlist(lapply(mods, function(l) l$ooberr))
  mods[[which.min(prfs)]]
}

